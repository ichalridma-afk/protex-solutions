import ProtexSolutions from './ProtexSolutions'

function App() {
  return <ProtexSolutions />
}

export default App
